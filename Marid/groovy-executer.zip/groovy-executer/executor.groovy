@Grab('log4j:log4j:1.2.17')
import org.apache.log4j.*
import groovy.util.logging.*
import groovy.io.FileType
import groovy.json.JsonSlurper
import groovy.cli.commons.CliBuilder

//parse cli args
def home = new File(getClass().protectionDomain.codeSource.location.path).parent
def cli = new CliBuilder()	
cli.with  
{  
	apiKey(longOpt: 'apiKey', 'Api Key', args: 1, required: true)  
	opsgenieUrl(longOpt: 'opsgenieUrl', 'Opsgenie API Url', args: 1, required: true)  
	payload(longOpt: 'payload', 'Queue payload', args: 1, required: true)
  logLevel(longOpt: 'logLevel', 'Log level', args: 1, required: true)
}  
def options = cli.parse(args)
String scriptFileName = options.arguments()[0]

// initalize logger
def config = new ConfigSlurper().parse(new File(home + '/log4jconfig.groovy').toURL())
config.log4j.rootLogger = options.logLevel.toLowerCase() + ',scrlog,stdout'
PropertyConfigurator.configure(config.toProperties())
Logger logger = LogManager.getLogger(getClass())

// set variables
def jsonSlurper = new JsonSlurper()
def payload = jsonSlurper.parseText(options.payload)
def opsgenieUrl = options.opsgenieUrl
def apiKey = options.apiKey
def mappedAction = ""
def action = ""
if(payload.containsKey("mappedActionV2"))
  mappedAction = payload["mappedActionV2"]["name"]
if(payload.containsKey("action"))
  action = payload["action"]
def params = [:]
params["alertId"] = payload["alert"]["alertId"]
params["body"] = payload
params << payload["params"]

// Load jar files from script's directory
scriptDir = home  + "/builds"
File folder = new File(scriptDir)
folder.eachFileRecurse FileType.FILES,  { file ->
    if (file.name.endsWith(".jar")) {
    	try {
        	this.getClass().classLoader.rootLoader.addURL(new File(scriptDir + '/' + file.name).toURI().toURL())
    		logger.debug("Imported jar file " + file.name)
    	}
    	catch (Exception e) {
    		logger.warn("Could not import the jar file " + file.name, e)
    	}  
    }
}

// read properties
def conf = new Properties()
try {
	new File("./opsgenie-integration.conf").withInputStream { s ->
  		conf.load(s) 
	}	
}
catch(FileNotFoundException e) {
   logger.debug("opsgenie-integration.conf - file not found")
}

try {
	new File("./marid.conf").withInputStream { s ->
  		conf.load(s) 
	}	
}
catch(FileNotFoundException e) {
   logger.debug("marid.conf - file not found")
}

// set up api client
def apiClient = Class.forName("com.opsgenie.oas.sdk.ApiClient").newInstance()
apiClient.setConnectTimeout(50000)
apiClient.setBasePath(opsgenieUrl)
apiClient.setApiKey(apiKey)
apiClient.setApiKeyPrefix("GenieKey")
def scriptProxy = Class.forName("com.ifountain.opsgenie.client.script.util.ScriptProxy").newInstance(apiClient)

// start the execution
def script = new GroovyShell()
script.setVariable("logger", logger)
script.setVariable("mappedAction", mappedAction)
script.setVariable("action", action)
script.setVariable("alert", payload["alert"])
script.setVariable("source", payload["source"])
script.setVariable("params", params)
script.setVariable("conf", conf)
script.setVariable("opsgenie", scriptProxy)
script.run(new File(scriptFileName))
