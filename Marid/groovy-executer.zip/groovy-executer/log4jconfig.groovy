log4j {
    appender.stdout = "org.apache.log4j.ConsoleAppender"
    appender."stdout.layout"="org.apache.log4j.PatternLayout"
    appender."stdout.layout.ConversionPattern"="%d{yy/MM/dd HH:mm:ss.SSS} %p: %m%n"

    appender.scrlog = "org.apache.log4j.DailyRollingFileAppender"
    appender."scrlog.layout"="org.apache.log4j.PatternLayout"
    appender."scrlog.file"="/var/log/opsgenie/marid/script.log"
    appender."scrlog.datePattern"="'.'yyyy-MM-dd"
    rootLogger=""
}


